from django.apps import AppConfig


class DddConfig(AppConfig):
    name = 'ddd'
