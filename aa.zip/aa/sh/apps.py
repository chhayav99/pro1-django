from django.apps import AppConfig


class ShConfig(AppConfig):
    name = 'sh'
